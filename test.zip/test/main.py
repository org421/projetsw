#!/usr/bin/env python3
"""
Main script - Étape 5 (améliorée): Génération RDF pour TOUS les types d'infobox

Ce script:
- Utilise le parser générique pour tous les types d'infobox
- Génère des triplets RDF automatiquement
- Supporte les 48+ templates utilisés sur Tolkien Gateway
"""

from tolkien_kg.api import MediaWikiClient
from tolkien_kg.parsers import GenericInfoboxParser, CharacterInfoboxParser, LocationInfoboxParser
from tolkien_kg.rdf import RDFGenerator, VocabularyGenerator


def print_separator(title: str):
    """Affiche un séparateur visuel."""
    print("\n" + "=" * 70)
    print(f" {title}")
    print("=" * 70 + "\n")


def get_all_used_templates(client: MediaWikiClient) -> list:
    """
    Récupère tous les templates d'infobox qui ont au moins une page.
    """
    print("Récupération des templates utilisés...")
    
    templates = client.get_all_infobox_templates()
    used_templates = []
    
    for template in templates:
        template_name = template['title'].replace('Template:', '')
        # Vérifier si au moins une page utilise ce template
        pages = list(client.get_pages_using_template(template_name, limit=1))
        if pages:
            count = client.count_pages_using_template(template_name)
            used_templates.append({
                'name': template_name,
                'count': count
            })
            print(f"  [OK] {template_name}: {count} pages")
        else:
            print(f"  [--] {template_name}: 0 pages")
    
    # Trier par nombre de pages
    used_templates.sort(key=lambda x: x['count'], reverse=True)
    
    return used_templates


def generate_kg_for_template(client: MediaWikiClient, parser: GenericInfoboxParser,
                              rdf_gen: RDFGenerator, template_name: str, limit: int = None):
    """
    Génère le RDF pour toutes les pages utilisant un template donné.
    
    Args:
        client: Client MediaWiki
        parser: Parser générique
        rdf_gen: Générateur RDF
        template_name: Nom du template
        limit: Limite de pages (None = toutes)
    """
    count = 0
    errors = 0
    
    for page in client.get_pages_using_template(template_name, limit=limit):
        title = page['title']
        
        try:
            wikitext = client.get_page_wikitext(title)
            if wikitext:
                entity = parser.parse_any(wikitext, page_title=title)
                if entity:
                    rdf_gen.add_entity(entity)
                    count += 1
                else:
                    errors += 1
        except Exception as e:
            errors += 1
            print(f"    [ERR] {title}: {e}")
    
    return count, errors


def generate_full_kg(client: MediaWikiClient, parser: GenericInfoboxParser,
                     rdf_gen: RDFGenerator, templates: list, limit_per_template: int = None):
    """
    Génère le Knowledge Graph complet pour tous les templates.
    
    Args:
        client: Client MediaWiki
        parser: Parser générique
        rdf_gen: Générateur RDF
        templates: Liste des templates à traiter
        limit_per_template: Limite de pages par template (None = toutes)
    """
    print_separator("GÉNÉRATION DU KNOWLEDGE GRAPH COMPLET")
    
    total_count = 0
    total_errors = 0
    
    for template_info in templates:
        template_name = template_info['name']
        template_count = template_info['count']
        
        # Afficher la progression
        actual_limit = limit_per_template if limit_per_template else template_count
        print(f"\n--- {template_name} ({min(actual_limit, template_count)}/{template_count} pages) ---")
        
        count, errors = generate_kg_for_template(
            client, parser, rdf_gen, template_name, limit=limit_per_template
        )
        
        total_count += count
        total_errors += errors
        
        print(f"    Traité: {count}, Erreurs: {errors}")
    
    print(f"\n{'='*50}")
    print(f"TOTAL: {total_count} entités générées, {total_errors} erreurs")
    print(f"{'='*50}")
    
    return total_count, total_errors


def demo_statistics(rdf_gen: RDFGenerator):
    """Affiche les statistiques du graphe."""
    print_separator("STATISTIQUES DU GRAPHE")
    
    stats = rdf_gen.get_statistics()
    
    print(f"Nombre total de triplets: {stats['total_triples']}")
    print(f"Nombre de sujets uniques: {stats['subjects']}")
    print(f"Nombre de prédicats uniques: {stats['predicates']}")
    print(f"Nombre d'objets uniques: {stats['objects']}")
    
    print(f"\nDistribution par type:")
    for type_name, count in sorted(stats['types'].items(), key=lambda x: -x[1])[:20]:
        print(f"  {type_name}: {count}")


def main():
    """Fonction principale."""
    print("\n" + "#" * 70)
    print("#" + " " * 68 + "#")
    print("#     TOLKIEN KNOWLEDGE GRAPH - Génération Complète                   #")
    print("#     Support de TOUS les types d'infobox                             #")
    print("#" + " " * 68 + "#")
    print("#" * 70)
    
    # Initialiser les composants
    client = MediaWikiClient()
    parser = GenericInfoboxParser()
    rdf_gen = RDFGenerator()
    
    # 1. Générer le vocabulaire
    print_separator("GÉNÉRATION DU VOCABULAIRE")
    vocab_gen = VocabularyGenerator()
    vocab_gen.generate_vocabulary()
    vocab_gen.save("tolkien_vocabulary.ttl")
    
    # 2. Récupérer tous les templates utilisés
    print_separator("ANALYSE DES TEMPLATES")
    templates = get_all_used_templates(client)
    
    print(f"\n{len(templates)} templates avec des pages trouvés")
    print("\nTop 10:")
    for i, t in enumerate(templates[:10], 1):
        print(f"  {i}. {t['name']}: {t['count']} pages")
    
    # 3. Générer le KG
    # Option: limiter le nombre de pages par template pour les tests
    # Mettre limit_per_template=None pour tout générer
    LIMIT_PER_TEMPLATE = 100  # Mettre None pour tout générer
    
    print(f"\nLimite par template: {LIMIT_PER_TEMPLATE or 'AUCUNE (tout générer)'}")
    
    generate_full_kg(client, parser, rdf_gen, templates, limit_per_template=LIMIT_PER_TEMPLATE)
    
    # 4. Statistiques
    demo_statistics(rdf_gen)
    
    # 5. Sauvegarder
    print_separator("SAUVEGARDE")
    rdf_gen.save("tolkien_kg.ttl", format="turtle")
    rdf_gen.save("tolkien_kg.nt", format="nt")
    
    # 6. Aperçu
    print_separator("APERÇU DU TURTLE (premiers 3000 caractères)")
    turtle = rdf_gen.serialize(format="turtle")
    print(turtle[:3000])
    if len(turtle) > 3000:
        print(f"\n... ({len(turtle)} caractères au total)")
    
    print("\n" + "=" * 70)
    print(" FIN")
    print("=" * 70)
    print("\nFichiers générés:")
    print("  - tolkien_vocabulary.ttl")
    print("  - tolkien_kg.ttl")
    print("  - tolkien_kg.nt")
    print(f"\nPour générer le KG complet, modifier LIMIT_PER_TEMPLATE = None dans main.py")


if __name__ == "__main__":
    main()
